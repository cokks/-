from tkinter import *
from tkinter.messagebox import *
import socket
import threading
import sys

def callexit(event):
    pos = "exit|"
    sendMessage(pos)
    sys.exit()

def drawQiPan():
    for i in range(0, 4):
        cv.create_line(20, 20 + 120 * i, 380, 20 + 120 * i, width=2)
    for i in range(0, 4):
        cv.create_line(20 + 120 * i, 20, 20 + 120 * i, 380, width=2)
        draw_my_chess()
        cv.pack()

#绘制棋子
def draw_my_chess():
    for i in range(4):
        for j in range(4):
            if map[j][i] == 1:
                cv.create_image(20 + i * 120, 20 + j * 120, image=imgs[0], anchor='c')
            elif map[j][i] == 0:
                cv.create_image(20 + i * 120, 20 + j * 120, image=imgs[1], anchor='c')
        cv.pack()

def sendMessage(pos):
    global s
    global addr
    s.sendto(pos.encode(),addr)

def click(event):
    global turn
    global myturn
    global arr
    if myturn == -1:
        myturn = turn
    else:
        if myturn != turn:
            showinfo(title="提示", message="还没轮到您走棋!")
            return
    # 20 200 380
    x = event.x
    y = event.y
    x, y = posgrid(x, y)
    if x == -1 or y == -1:
        return
    if len(arr) == 0:
        #第一步点击的不是自己的棋子
        if map[y][x] != myturn:
            showinfo(title="提示", message="走法不合规")
            return
        print(2)
        arr.append(x)
        arr.append(y)
        return
    else:
        arr.append(x)
        arr.append(y)
        if walk(arr):

            index = map[arr[1]][arr[0]]
            map[arr[1]][arr[0]] = map[arr[3]][arr[2]]
            map[arr[3]][arr[2]] = index
            eatChess()
            arr.clear()
            cv.delete("all")
            drawQiPan()
            # 将map中的元素转换为字符串交给另一端
            output = ','.join([str(item) for row in map for item in row])
            # sendMessage('move|' + output)
            if win_lose():
                 if turn == 0:
                     showinfo(title='提示', message='白方胜利')
                     con = 1
            #         # output = ','.join([str(item) for row in map for item in row])
            #         # sendMessage('move|' + output)
                     sendMessage('over|白方胜利')
                 else:
                     showinfo(title='提示', message='黑方胜利')
                     con = 1
                     # output = ','.join([str(item) for row in map for item in row])
                     # sendMessage('move|' + output)
                     sendMessage('over|黑 方胜利')
            sendMessage('move|' + output)
            switch_player()
        else:
            arr.clear()
            showinfo(title='提示', message='本次移动不合法，请重新操作')

def win_lose():
    # 记录相反的棋子
    a = 1 - turn
    for i in range(0, 4):
        for j in range(0, 4):
            if map[i][j] == a:
                return False
    return True

def posgrid(x,y):
    a = -1
    b = -1
    for i in range(0,4):
        if 20 + i * 120 - 20 <= x and 20 + i * 120 + 20 >= x:
            a = i
            break
    for i in range(0,4):
        if 20 + i * 120 - 20 <= y and 20 + i * 120 + 20 >= y:
            b = i
            break
    return a,b

def walk(arr):
    if map[arr[3]][arr[2]] != '':
        return False
    else:
        if abs(arr[0] - arr[2]) == 1 and abs(arr[1] - arr[3]) == 1:
            return False
    return True

def receiveMessage():
    global s
    while True:
        #接收客户端发送的消息
        global addr
        global map
        global myturn
        data, addr = s.recvfrom(1024)
        data=data.decode('utf-8')
        a=data.split("|")                          #分割数据
        if not data:
            print('client has exited!')
            break
        elif a[0] == 'join':                      #连接服务器请求
            print('client 连接服务器!')
            label1["text"]='client 连接服务器成功，请你走棋！'
        elif a[0] == 'exit':                      #对方退出信息
            print('client 对方退出!')
            label1["text"]='client 对方退出，游戏结束！'
        elif a[0] == 'over':        #对方赢信息
            print('对方赢信息!')
            label1["text"]=data.split("|")[0]
            showinfo(title="提示",message=data.split("|")[1] )
        elif a[0] == 'move':        #客户端走的位置信息
            string_list = a[1].split(',')  # 首先将字符串按逗号分隔成一个列表
            map = [[int(string_list[i * 4 + j]) if i * 4 + j < len(string_list) and string_list[i * 4 + j] != '' else '' for j in range(4)] for i in range(4)]
            cv.delete("all")
            drawQiPan()
            switch_player()
    s.close()

def switch_player():
    global turn
    if turn == 1:
        turn = 0
    else:
        turn = 1

def startNewThread( ):
    thread=threading.Thread(target=receiveMessage,args=())
    thread.setDaemon(True);
    thread.start();


def eatChess():
    global map
    global arr
    player_piece = map[arr[3]][arr[2]]  # 当前要移动的棋子
    x, y = arr[2], arr[3]  # 当前棋子的坐标
    rows, cols = len(map), len(map[0])  # 棋盘的行数和列数


    # 定义函数来检查指定方向上是否可以吃子
    def check_direction(dx, dy):
        nonlocal x, y
        count = 0  # 记录连续己棋的数量
        enemy_pos = None  # 记录敌棋的位置
        while 0 <= x < cols and 0 <= y < rows:
            x += dx
            y += dy
            if 0 <= x < cols and 0 <= y < rows:
                if map[y][x] == '':
                    break
                elif map[y][x] == player_piece:
                    count += 1
                else:
                    enemy_pos = (x, y)
                    break

        if count == 1 and enemy_pos:
            map[enemy_pos[1]][enemy_pos[0]] = ''

    # 检查横竖两个方向
    for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        x, y = arr[2], arr[3]  # 重置坐标
        check_direction(dx, dy)

def win_lose():
    #记录相反的棋子
    a = 1 - turn
    for i in range(0,3):
        for j in range(0,3):
            if map[i][j] == a:
                return False
    return True


root = Tk()
root.title("网络炮棋V2.1--服务器端")
#五子棋--夏敏捷2016-2-11,仨个小时 网络版
imgs = [PhotoImage(file="D:/Desktop/black_mini.gif"), PhotoImage(file="D:/Desktop/white_mini.gif")]
turn = 0
myturn=-1
con = 0
arr = []
map = [["", "", "", ""] for y in range(4)]
map[0][0] = map[0][1] = map[0][2] = map[0][3] = map[1][0] = map[1][3] = 0  # 黑子
map[3][0] = map[3][1] = map[3][2] = map[3][3] = map[2][0] = map[2][3] = 1  # 白字
cv = Canvas(root, bg="#EE9A49", width=400, height=400)
# 绑定鼠标点击和释放事件
cv.bind("<Button-1>", click)
drawQiPan()

cv.pack()
label1=Label(root,text="服务器端....")
label1.pack()
button1=Button(root,text="退出游戏")
button1.bind("<Button-1>", callexit)
button1.pack()
#创建UDP SOCKET
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind(('localhost',8001))
addr=('localhost',8001)
startNewThread()       ## 启动线程接收客户端的消息receiveMessage();
root.mainloop()
