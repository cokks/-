from tkinter import *
from tkinter.messagebox import *
import socket
import threading
import sys

# tkinter：这是 Python 的标准图形用户界面库。
# tkinter.messagebox：提供消息框功能，用于显示提示、警告等信息。
# socket：用于创建网络通信。
# threading：用于创建和管理线程，特别是在处理网络通信时。
# sys：提供与 Python 解释器和系统相关的功能，例如退出程序等

def callexit(event):
    pos = "exit|"
    sendMessage(pos)
    sys.exit()

def calljoin(event):
    pos = 'join|'  # "连接服务器"命令
    sendMessage(pos)  # 发送连接服务器请求
    startNewThread()

def sendMessage(pos):
    global s
    s.sendto(pos.encode(), (host, port))

# callexit(event)：这个函数在事件触发时调用（例如按下某个按钮）。它发送一个“退出”消息给服务器，然后调用 sys.exit() 退出程序。
# calljoin(event)：这个函数在事件触发时调用，发送一个“加入”消息给服务器，并启动一个新线程。
# sendMessage(pos)：将 pos 消息编码后通过套接字（socket）发送到指定主机和端口。
# drawQiPan()：这个函数用于绘制棋盘。它创建了棋盘的线条并调用 draw_my_chess() 绘制棋子。
# draw_my_chess()：这个函数用于绘制棋子。它遍历棋盘上的每个位置，根据 map 数组中的值选择显示不同的棋子图像。
# click(event)：处理棋盘上的点击事件。根据点击的位置确定下棋位置，并执行移动。如果移动有效，则更新棋盘并检查胜负情况。


def drawQiPan():#绘制棋盘
    for i in range(0, 4):
        cv.create_line(20, 20 + 120 * i, 380, 20 + 120 * i, width=2)
    for i in range(0, 4):
        cv.create_line(20 + 120 * i, 20, 20 + 120 * i, 380, width=2)
        draw_my_chess()
        cv.pack()

def draw_my_chess():#绘制棋子

    for i in range(4):
        for j in range(4):
            if map[j][i] == 1:
                cv.create_image(20 + i * 120, 20 + j * 120, image=imgs[0], anchor='c')
            elif map[j][i] == 0:
                cv.create_image(20 + i * 120, 20 + j * 120, image=imgs[1], anchor='c')
        cv.pack()

def click(event):
    global turn
    global myturn
    global arr
    if myturn == -1:
        myturn = turn
    else:
        if myturn != turn:
            showinfo(title="提示", message="还没轮到您走棋!")
            return
    # 20 200 380
    x = event.x
    y = event.y
    x, y = posgrid(x, y)
    if x == -1 or y == -1:
        return
    if len(arr) == 0:
        #第一步点击的不是自己的棋子
        if map[y][x] != myturn:
            showinfo(title="提示", message="走法不合规")
            return

        arr.append(x)
        arr.append(y)
        return
    else:
        arr.append(x)
        arr.append(y)
        if walk(arr):

            index = map[arr[1]][arr[0]]
            map[arr[1]][arr[0]] = map[arr[3]][arr[2]]
            map[arr[3]][arr[2]] = index
            eatChess()
            arr.clear()
            cv.delete("all")
            drawQiPan()
            # 将map中的元素转换为字符串交给另一端
            output = ','.join([str(item) for row in map for item in row])
            if win_lose():
                 if turn == 0:
                     showinfo(title='提示', message='白方胜利')
                     con = 1
                     sendMessage('over|白方胜利')
                 else:
                     showinfo(title='提示', message='黑方胜利')
                     con = 1
                     sendMessage('over|黑方胜利')
            switch_player()
            sendMessage('move|' + output)
        else:
            arr.clear()
            showinfo(title='提示', message='本次移动不合法，请重新操作')

def posgrid(x,y):
    a = -1
    b = -1
    for i in range(0,4):
        if 20 + i * 120 - 20 <= x and 20 + i * 120 + 20 >= x:
            a = i
            break
    for i in range(0,4):
        if 20 + i * 120 - 20 <= y and 20 + i * 120 + 20 >= y:
            b = i
            break
    return a,b

# a = -1 和 b = -1：初始化两个变量用于记录棋盘格子的索引，默认值为 -1。
#
# for i in range(0,4):：使用循环遍历棋盘的行和列。
#
# if 20 + i * 120 - 20 <= x and 20 + i * 120 + 20 >= x:：检查鼠标点击的 x 坐标是否位于第 i 列棋盘格子的范围内。这里的计算是基于棋盘格子的宽度为 120，并且在计算时考虑了格子的边界，左右各留出 20 个像素的空白。
#
# 如果条件成立，则将当前列的索引赋值给变量 a，并且通过 break 终止循环。
#
# for i in range(0,4):：同样，使用循环遍历棋盘的行。
#
# if 20 + i * 120 - 20 <= y and 20 + i * 120 + 20 >= y:：检查鼠标点击的 y 坐标是否位于第 i 行棋盘格子的范围内，采用类似的计算方式。
#
# 如果条件成立，则将当前行的索引赋值给变量 b，并且通过 break 终止循环。
#
# return a, b：返回计算得到的棋盘格子的行列索引。如果鼠标点击位置不在棋盘格子范围内，则返回的索引值为 -1。综上所述，这段代码的作用是根据鼠标点击的坐标，计算出对应的棋盘格子的行列索引。

def win_lose():#判断输赢
    # 记录相反的棋子
    a = 1 - turn
    for i in range(0, 4):
        for j in range(0, 4):
            if map[i][j] == a:
                return False
    return True
#横纵坐标的遍历看是否还有对方的棋子
#限制走棋
def walk(arr):#走棋限制（一步）
    if map[arr[3]][arr[2]] != '':
        return False
    else:
        if abs(arr[0] - arr[2]) == 1 and abs(arr[1] - arr[3]) == 1:
            return False
    return True

def receiveMessage():
    global s
    while True:
        #接收客户端发送的消息
        global addr
        global map
        global myturn
        data, addr = s.recvfrom(1024)
        data=data.decode('utf-8')
        a=data.split("|")                          #分割数据
        if not data:
            print('client has exited!')
            break
        elif a[0] == 'join':                      #连接服务器请求
            print('client 连接服务器!')
            label1["text"]='client 连接服务器成功，请你走棋！'
        elif a[0] == 'exit':                      #对方退出信息
            print('client 对方退出!')
            label1["text"]='client 对方退出，游戏结束！'
        elif a[0] == 'over':        #对方赢信息
            print('对方赢信息!')
            label1["text"]=data.split("|")[0]
            showinfo(title="提示",message=data.split("|")[1] )
        elif a[0] == 'move':        #客户端走的位置信息
            string_list = a[1].split(',')  # 首先将字符串按逗号分隔成一个列表
            map = [[int(string_list[i * 4 + j]) if i * 4 + j < len(string_list) and string_list[i * 4 + j] != '' else '' for j in range(4)] for i in range(4)]
            cv.delete("all")
            drawQiPan()
            switch_player()
    s.close()

def switch_player():#记录下棋玩家实现回合的轮替
    global turn
    if turn == 1:
        turn = 0
    else:
        turn = 1

def startNewThread( ):
    thread=threading.Thread(target=receiveMessage,args=())
    thread.start();#这段代码的作用是在一个新的线程中运行 receiveMessage() 函数，这样可以使接收消息的操作在后台进行，而不会阻塞主线程，保持程序的响应性。


def eatChess():
    global map
    global arr
    player_piece = map[arr[3]][arr[2]]  # 当前要移动的棋子
    x, y = arr[2], arr[3]  # 当前棋子的坐标
    rows, cols = len(map), len(map[0])  # 棋盘的行数和列数获取当前要移动的棋子，arr 是一个列表，其中 arr[2] 和 arr[3] 分别表示棋子的横纵坐标，map 是一个全局变量，表示棋盘的状态。

    # 定义函数来检查指定方向上是否可以吃子
    def check_direction(dx, dy):# 函数中，通过不断移动坐标 (x, y)，检查指定方向上的棋子情况。如果遇到空白格子，则停止搜索；如果遇到对方的棋子，则记录其位置；如果遇到己方的棋子，则判断是否有机会吃掉对方的棋子，如果是，则将对方的棋子吃掉。
        nonlocal x, y
        count = 0  # 记录连续己棋的数量
        enemy_pos = None  # 记录敌棋的位置
        while 0 <= x < cols and 0 <= y < rows:
            x += dx
            y += dy
            if 0 <= x < cols and 0 <= y < rows:
                if map[y][x] == '':
                    break
                elif map[y][x] == player_piece:
                    count += 1
                else:
                    enemy_pos = (x, y)
                    break

        if count == 1 and enemy_pos:
            map[enemy_pos[1]][enemy_pos[0]] = ''

    # 检查横竖两个方向
    for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        x, y = arr[2], arr[3]  # 重置坐标
        check_direction(dx, dy)


root = Tk()
root.title("网络炮棋V2.1--客户端")
arr = []
turn = 0
myturn = -1
imgs = [PhotoImage(file="D:/Desktop/black_mini.gif"), PhotoImage(file="D:/Desktop/white_mini.gif")]
map = [["", "", "", ""] for y in range(4)]
map[0][0] = map[0][1] = map[0][2] = map[0][3] = map[1][0] = map[1][3] = 0  # 黑子
map[3][0] = map[3][1] = map[3][2] = map[3][3] = map[2][0] = map[2][3] = 1  # 白字
cv = Canvas(root, bg="#EE9A49", width=400, height=400)
cv.bind("<Button-1>", click)
drawQiPan()

cv.pack()
label1 = Label(root, text="客户端....")
label1.pack()

v = StringVar()
entryServerIP = Entry(root, textvariable=v)  # Entry组件
v.set("127.0.0.1")  # 设置StringVar变量的值，Entry组件文本自动更新
entryServerIP.pack()

f = Frame(root)
button0 = Button(f, text="连接服务器")
button0.bind("<Button-1>", calljoin)
button0.pack(side='left')
button1 = Button(f, text="退出游戏")
button1.bind("<Button-1>", callexit)
button1.pack(side='left')
f.pack()
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
port = 8001  # 服务器端口
host = entryServerIP.get()  # 服务器地址 192.168.0.1011
root.mainloop()

